# Roguelike Deckbuilder Card UI — Godot 4 Package (v2)

Drop-in `Card` Control node matching the latest mockup. Built entirely from
`Control` / `PanelContainer` / `Label` / `TextureRect` / `HBoxContainer` —
no shaders, no custom drawing.

## What's new in v2

- **Header strip:** replay badge, value bar, and cost coin are now a single
  horizontal band overlapping the top edge of the card.
- **Socket bar with mana spheres:** the value bar is a chain of round
  brass-rimmed sockets. The number of sockets matches the mana cost.
- **Tier color = mana cost:**
  - 1 mana → 1 sphere, **red** bar + red accent on top of the art frame
  - 2 mana → 2 spheres, **yellow** bar + yellow accent
  - 3 mana → 3 spheres, **blue** bar + blue accent
- **Smaller, matte mana spheres** (13px, no shiny highlight).
- **Upward-facing dagger** on the bottom-left attack plaque (mirrors the
  shield plaque on the right).
- **Closed top gap:** the art frame now sits flush against the inner
  card border, with the header strip overlapping its top edge.

## Package contents

```
godot_card_ui/
├── assets/
│   ├── filigree_corner.svg   # Brass corner ornament
│   ├── stat_sword.svg        # Sword-arrowhead attack plaque
│   ├── stat_shield.svg       # Shield block plaque
│   ├── icon_replay.svg       # Loop arrow for the replay badge
│   ├── mana_sphere.svg       # Single matte mana gem
│   ├── bar_1_red.svg         # 1-mana socket bar (red)
│   ├── bar_2_yellow.svg      # 2-mana socket bar (yellow)
│   └── bar_3_blue.svg        # 3-mana socket bar (blue)
├── scenes/
│   └── card.tscn             # The Card scene
├── scripts/
│   └── card.gd               # @tool script with @export properties
└── theme/
    └── card_theme.tres       # Optional shared styleboxes
```

## Installation

1. Copy the four folders into your Godot project under `res://`. Paths
   referenced in the scene assume:
   - `res://assets/...`
   - `res://scenes/card.tscn`
   - `res://scripts/card.gd`
2. Open `scenes/card.tscn` — the `@tool` script means the editor renders
   it live.
3. (Optional) For crisper SVGs at large sizes, select each SVG in the
   FileSystem dock, switch to the Import tab, set **Scale** = 2.0–4.0,
   and click **Reimport**.

## Runtime usage

```gdscript
var card_scene := preload("res://scenes/card.tscn")
var card: Card = card_scene.instantiate()

card.card_name  = "Cleave"
card.description = "Sweep through every foe at once."
card.cost = 3                # 1 / 2 / 3 — drives bar, spheres, and tier color
card.attack = 14
card.block  = -1             # -1 → dim em-dash
card.shows_replay_icon = true
card.card_art = preload("res://art/cleave.png")

$Hand.add_child(card)
```

You only set `cost`. The bar texture, mana sphere count, and the tier
accent strip on the art frame all update from that single property.

## Layout anatomy

```
PanelContainer  Card (4px black border, tan parchment fill)
├── VBoxContainer "Layout"
│   ├── PanelContainer "ArtFrame"    (silvery steel border, sits at top)
│   │   ├── Panel "TierStrip"        (red/yellow/blue accent inside top edge)
│   │   └── VBoxContainer
│   │       ├── PanelContainer "NamePlate" → Label
│   │       └── PanelContainer "ArtRecess" → TextureRect (the art)
│   └── MarginContainer "DescMargin" → Label
├── 4 × TextureRect "CornerXX"
├── HBoxContainer "HeaderStrip"      (overhangs ±8px, sits at -10px,
│   │                                 covers top edge of ArtFrame)
│   ├── PanelContainer "ReplayBadge" → TextureRect
│   ├── Control "BarHolder"
│   │   ├── TextureRect "BarTexture" (the socket bar)
│   │   └── HBoxContainer "ManaSpheres" → 1–3 × TextureRect
│   └── PanelContainer "CostCoin" → Label
├── Control "AttackStat"  (bottom-left, overhanging — upward dagger)
└── Control "BlockStat"   (bottom-right, overhanging)
```

## Customization

- **Tier colors:** edit `TIER_RED` / `TIER_YELLOW` / `TIER_BLUE` constants
  at the top of `card.gd`. The bar SVGs have their colors hardcoded — if
  you want different bar colors, edit the `<linearGradient>` stops in
  `bar_1_red.svg` / `bar_2_yellow.svg` / `bar_3_blue.svg`.
- **Card frame color:** `SB_card_body.bg_color` in `card.tscn` — currently
  `Color(0.847, 0.722, 0.471)` (warm parchment).
- **Steel art frame tint:** `SB_art_frame.bg_color`, currently
  `Color(0.416, 0.431, 0.471)` (brushed steel grey).
- **Header strip vertical offset:** edit `HeaderStrip.offset_top` (default
  `-10.0`) to push it higher or lower over the card edge.

## Known limitations

- StyleBoxFlat doesn't support gradients. The cost coin, replay badge,
  and tier strip use flat fills. The bar SVGs *do* have gradients because
  they're rendered as textures, not styleboxes. For gradient styleboxes
  on the buttons, swap to `StyleBoxTexture` with 9-slice PNGs.
- The bar's mana-sphere positions inside the SVGs are calibrated for
  the default 124px card width. If you scale the card significantly,
  re-align the `ManaSpheres` HBoxContainer offsets in the scene file.
