@tool
class_name Card
extends PanelContainer

## A roguelike deckbuilder card.
##
## Mana cost (1, 2, or 3) drives the value bar, sphere count, and tier color
## together — set `cost` and the rest follows automatically:
##   1 mana → 1 sphere, red bar + red top accent on the art frame
##   2 mana → 2 spheres, yellow bar + yellow accent
##   3 mana → 3 spheres, blue bar + blue accent
##
## attack/block of -1 displays a dimmed em-dash.

# --- Bar textures (one per cost; set in _ready) ---
const BAR_TEXTURES := {
	1: preload("res://assets/bar_1_red.svg"),
	2: preload("res://assets/bar_2_yellow.svg"),
	3: preload("res://assets/bar_3_blue.svg"),
}
const MANA_SPHERE := preload("res://assets/mana_sphere.svg")

# --- Tier accent colors (also baked into the SB_tier_* styleboxes) ---
const TIER_RED    := Color(0.816, 0.282, 0.282)
const TIER_YELLOW := Color(0.941, 0.784, 0.282)
const TIER_BLUE   := Color(0.353, 0.627, 0.847)

const COLOR_STAT_ACTIVE := Color(0.973, 0.910, 0.769)
const COLOR_STAT_DIM    := Color(0.541, 0.478, 0.353, 0.55)

@export var card_name: String = "Iron Strike":
	set(v): card_name = v; _refresh_name()

@export_multiline var description: String = "Strike a foe with your blade.":
	set(v): description = v; _refresh_desc()

@export_range(1, 3) var cost: int = 1:
	set(v):
		cost = clamp(v, 1, 3)
		_refresh_cost()
		_refresh_bar()
		_refresh_spheres()
		_refresh_tier_strip()

## Set to -1 for "no attack value"
@export var attack: int = 9:
	set(v): attack = v; _refresh_attack()

## Set to -1 for "no block value"
@export var block: int = -1:
	set(v): block = v; _refresh_block()

@export var card_art: Texture2D:
	set(v): card_art = v; _refresh_art()

@export var shows_replay_icon: bool = true:
	set(v): shows_replay_icon = v; _refresh_replay()

# --- Cached node refs ---
@onready var _name_label: Label      = $Layout/ArtFrame/ArtVBox/NamePlate/NameLabel
@onready var _desc_label: Label      = $Layout/DescMargin/DescLabel
@onready var _cost_label: Label      = $HeaderStrip/CostCoin/CostLabel
@onready var _bar_tex: TextureRect   = $HeaderStrip/BarHolder/BarTexture
@onready var _spheres: HBoxContainer = $HeaderStrip/BarHolder/ManaSpheres
@onready var _atk_num: Label         = $AttackStat/Number
@onready var _blk_num: Label         = $BlockStat/Number
@onready var _art: TextureRect       = $Layout/ArtFrame/ArtVBox/ArtRecess/ArtTexture
@onready var _replay: PanelContainer = $HeaderStrip/ReplayBadge
@onready var _tier_strip: Panel      = $Layout/ArtFrame/TierStrip

func _ready() -> void:
	_refresh_all()

func _refresh_all() -> void:
	_refresh_name()
	_refresh_desc()
	_refresh_cost()
	_refresh_bar()
	_refresh_spheres()
	_refresh_tier_strip()
	_refresh_attack()
	_refresh_block()
	_refresh_art()
	_refresh_replay()

func _refresh_name() -> void:
	if is_instance_valid(_name_label):
		_name_label.text = card_name

func _refresh_desc() -> void:
	if is_instance_valid(_desc_label):
		_desc_label.text = description

func _refresh_cost() -> void:
	if is_instance_valid(_cost_label):
		_cost_label.text = str(cost)

func _refresh_bar() -> void:
	if is_instance_valid(_bar_tex):
		_bar_tex.texture = BAR_TEXTURES.get(cost, BAR_TEXTURES[1])

func _refresh_spheres() -> void:
	if not is_instance_valid(_spheres): return
	# Clear and rebuild children to match mana count.
	for child in _spheres.get_children():
		child.queue_free()
	for i in cost:
		var s := TextureRect.new()
		s.texture = MANA_SPHERE
		s.custom_minimum_size = Vector2(13, 13)
		s.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		s.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		_spheres.add_child(s)

func _refresh_tier_strip() -> void:
	if not is_instance_valid(_tier_strip): return
	var sb := StyleBoxFlat.new()
	sb.border_width_left = 1
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.border_color = Color(0.020, 0.024, 0.031)
	sb.corner_radius_top_left = 2
	sb.corner_radius_top_right = 2
	sb.corner_radius_bottom_right = 2
	sb.corner_radius_bottom_left = 2
	match cost:
		1: sb.bg_color = TIER_RED
		2: sb.bg_color = TIER_YELLOW
		3: sb.bg_color = TIER_BLUE
	_tier_strip.add_theme_stylebox_override("panel", sb)

func _refresh_attack() -> void:
	if not is_instance_valid(_atk_num): return
	if attack < 0:
		_atk_num.text = "—"
		_atk_num.add_theme_color_override("font_color", COLOR_STAT_DIM)
	else:
		_atk_num.text = str(attack)
		_atk_num.add_theme_color_override("font_color", COLOR_STAT_ACTIVE)

func _refresh_block() -> void:
	if not is_instance_valid(_blk_num): return
	if block < 0:
		_blk_num.text = "—"
		_blk_num.add_theme_color_override("font_color", COLOR_STAT_DIM)
	else:
		_blk_num.text = str(block)
		_blk_num.add_theme_color_override("font_color", COLOR_STAT_ACTIVE)

func _refresh_art() -> void:
	if is_instance_valid(_art):
		_art.texture = card_art

func _refresh_replay() -> void:
	if is_instance_valid(_replay):
		_replay.visible = shows_replay_icon
