"""
Generates nine-patch textures for the Roguelike Deckbuilder Card UI.

Produces PNGs at 3x scale so they upscale cleanly. For each texture we
document the patch margins to use in Godot's NinePatchRect.

Output files (under assets/ninepatch/):
  card_body.png         — outer black border + tan parchment fill
  art_frame.png         — silvery steel border with rivet hint
  name_plate.png        — charcoal background with bottom black divider
  art_recess.png        — dark inner art recess
  cost_coin.png         — matte brass disc (stretchable but stays round)
  replay_badge.png      — silvery disc with chrome ring
  tier_red.png          — red gradient tier strip
  tier_yellow.png       — yellow gradient tier strip
  tier_blue.png         — blue gradient tier strip
"""

import os
from PIL import Image, ImageDraw, ImageFilter

SCALE = 3
OUT = "/home/claude/godot_card_ui/assets/ninepatch"
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------
# 1) CARD BODY — black 4px border + tan parchment fill
# Final intended displayed size: arbitrary (works for any card size).
# Source: 30x30 px (so 4px border * 3 = 12px, with 6px stretchable middle)
# Patch margin (Godot units, at 3x): 12 / 12 / 12 / 12
# ----------------------------------------------------------------------
def make_card_body():
    base_size = 30 * SCALE  # 90
    border = 4 * SCALE      # 12
    img = Image.new("RGBA", (base_size, base_size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Black border (with rounded corners)
    draw.rounded_rectangle(
        [(0, 0), (base_size - 1, base_size - 1)],
        radius=6 * SCALE,
        fill=(5, 6, 8, 255),
    )
    # Tan parchment interior with subtle vertical gradient
    inner = Image.new("RGBA", (base_size - border * 2, base_size - border * 2), (0, 0, 0, 0))
    idraw = ImageDraw.Draw(inner)
    for y in range(inner.size[1]):
        t = y / max(inner.size[1] - 1, 1)
        # warm parchment: brighter at top, deeper amber at bottom
        r = int(240 - 72 * t)   # 240 -> 168
        g = int(220 - 84 * t)   # 220 -> 136
        b = int(168 - 96 * t)   # 168 -> 72
        idraw.line([(0, y), (inner.size[0], y)], fill=(r, g, b, 255))
    # Soft inner highlight near the top
    glow = Image.new("RGBA", inner.size, (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    gdraw.ellipse(
        [(-inner.size[0] * 0.3, -inner.size[1] * 0.6),
         (inner.size[0] * 1.3, inner.size[1] * 0.6)],
        fill=(255, 230, 170, 60),
    )
    glow = glow.filter(ImageFilter.GaussianBlur(radius=4 * SCALE))
    inner = Image.alpha_composite(inner, glow)
    # Round inner corners slightly to match outer rounding minus border
    mask = Image.new("L", inner.size, 0)
    mdraw = ImageDraw.Draw(mask)
    mdraw.rounded_rectangle(
        [(0, 0), (inner.size[0] - 1, inner.size[1] - 1)],
        radius=2 * SCALE, fill=255,
    )
    inner.putalpha(mask)

    img.paste(inner, (border, border), inner)

    # Subtle warm rim just inside the black border (1px @ 3x = 3px line)
    draw.rounded_rectangle(
        [(border - 1, border - 1),
         (base_size - border, base_size - border)],
        radius=4 * SCALE, outline=(255, 220, 140, 90), width=SCALE,
    )

    img.save(f"{OUT}/card_body.png", "PNG")
    print(f"card_body.png ({base_size}x{base_size}, patch margin {border}/{border}/{border}/{border})")


# ----------------------------------------------------------------------
# 2) ART FRAME — silvery brushed-steel border with bevel + rivets
# Source: 24x24 px scaled (so 4px border * 3 = 12px)
# Patch margin: 12 / 12 / 12 / 12
# ----------------------------------------------------------------------
def make_art_frame():
    base = 24 * SCALE
    border = 4 * SCALE
    img = Image.new("RGBA", (base, base), (0, 0, 0, 0))

    # Outer black ring
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(
        [(0, 0), (base - 1, base - 1)],
        radius=3 * SCALE, fill=(5, 6, 8, 255),
    )
    # Steel band — vertical gradient bevel from light at top to dark at bottom
    steel = Image.new("RGBA", (base - 2 * SCALE, base - 2 * SCALE), (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(steel)
    for y in range(steel.size[1]):
        t = y / max(steel.size[1] - 1, 1)
        # 200,204,212 -> 106,110,120 -> 42,46,54
        if t < 0.5:
            t2 = t * 2
            r = int(200 - 94 * t2)
            g = int(204 - 94 * t2)
            b = int(212 - 92 * t2)
        else:
            t2 = (t - 0.5) * 2
            r = int(106 - 64 * t2)
            g = int(110 - 64 * t2)
            b = int(120 - 66 * t2)
        sdraw.line([(0, y), (steel.size[0], y)], fill=(r, g, b, 255))

    # NOTE: skip horizontal striations — they cause banding when nine-patch
    # stretches the middle row vertically. A smooth gradient nine-patches cleanly.

    img.paste(steel, (SCALE, SCALE), steel)

    # Inner black ring (separating steel from art recess)
    draw.rounded_rectangle(
        [(border - 1, border - 1),
         (base - border, base - border)],
        radius=2 * SCALE, outline=(5, 6, 8, 255), width=SCALE,
    )

    # Two rivet hints near the top corners (only visible when a thick top band shows)
    rivet_y = int(border * 0.5)
    for cx in [border, base - border - 1]:
        draw.ellipse([(cx - SCALE, rivet_y - SCALE), (cx + SCALE, rivet_y + SCALE)],
                     fill=(232, 236, 240, 255), outline=(5, 6, 8, 255), width=1)

    img.save(f"{OUT}/art_frame.png", "PNG")
    print(f"art_frame.png ({base}x{base}, patch margin {border}/{border}/{border}/{border})")


# ----------------------------------------------------------------------
# 3) NAME PLATE — charcoal panel with black bottom divider
# Source: 16x14 with 1px black bottom border
# Patch margin: 4 / 4 / 4 / 6 (extra bottom because of the 2px divider)
# ----------------------------------------------------------------------
def make_name_plate():
    w, h = 16 * SCALE, 14 * SCALE
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Charcoal vertical gradient
    for y in range(h - 2 * SCALE):
        t = y / max(h - 2 * SCALE - 1, 1)
        r = int(74 - 35 * t)
        g = int(78 - 36 * t)
        b = int(88 - 36 * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    # Black divider at bottom (2px @ 3x)
    draw.rectangle([(0, h - 2 * SCALE), (w, h)], fill=(5, 6, 8, 255))
    img.save(f"{OUT}/name_plate.png", "PNG")
    print(f"name_plate.png ({w}x{h}, patch margin 4/4/4/6 — at 3x: 12/12/12/18)")


# ----------------------------------------------------------------------
# 4) ART RECESS — dark inner area where card art is placed
# Source: 16x16 (no border, just a vignette)
# Patch margin: 4 / 4 / 4 / 4
# ----------------------------------------------------------------------
def make_art_recess():
    s = 16 * SCALE
    img = Image.new("RGBA", (s, s), (26, 14, 4, 255))
    # Soft vignette: lighter brown center fading to black at edges
    vignette = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    vdraw = ImageDraw.Draw(vignette)
    vdraw.ellipse([(s * 0.1, s * 0.15), (s * 0.9, s * 0.85)],
                  fill=(74, 56, 32, 220))
    vignette = vignette.filter(ImageFilter.GaussianBlur(radius=4 * SCALE))
    img = Image.alpha_composite(img, vignette)
    img.save(f"{OUT}/art_recess.png", "PNG")
    print(f"art_recess.png ({s}x{s}, patch margin 4/4/4/4 — at 3x: 12/12/12/12)")


# ----------------------------------------------------------------------
# 5) COST COIN — circular brass disc; works as nine-patch when stretched
#    near-square so the rounded corners stay circular at the source size
# Source: 12x12 with 6px corner radius (full circle)
# Patch margin: 6 / 6 / 6 / 6 (no stretch zone — keep at native size)
# ----------------------------------------------------------------------
def make_cost_coin():
    s = 12 * SCALE
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Black ring
    draw.ellipse([(0, 0), (s - 1, s - 1)], fill=(5, 6, 8, 255))
    # Brass interior with vertical gradient
    inner_r = int(s * 0.4)
    cx, cy = s // 2, s // 2
    inner = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    idraw = ImageDraw.Draw(inner)
    for y in range(s):
        t = y / max(s - 1, 1)
        r = int(200 - 56 * t)
        g = int(154 - 60 * t)
        b = int(74 - 34 * t)
        idraw.line([(0, y), (s, y)], fill=(r, g, b, 255))
    mask = Image.new("L", (s, s), 0)
    mdraw = ImageDraw.Draw(mask)
    mdraw.ellipse([(SCALE * 2, SCALE * 2), (s - SCALE * 2 - 1, s - SCALE * 2 - 1)], fill=255)
    inner.putalpha(mask)
    img = Image.alpha_composite(img, inner)
    # Subtle top sheen
    sheen = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    sd = ImageDraw.Draw(sheen)
    sd.ellipse([(SCALE * 3, SCALE * 2), (s - SCALE * 3, s * 0.55)],
               fill=(255, 220, 150, 60))
    sheen = sheen.filter(ImageFilter.GaussianBlur(radius=SCALE))
    img = Image.alpha_composite(img, sheen)
    img.save(f"{OUT}/cost_coin.png", "PNG")
    print(f"cost_coin.png ({s}x{s}, native circle — for NinePatchRect use margin 6/6/6/6 at 3x: 18/18/18/18)")


# ----------------------------------------------------------------------
# 6) REPLAY BADGE — silvery disc with chrome ring
# Same construction as cost coin but cooler tones
# ----------------------------------------------------------------------
def make_replay_badge():
    s = 12 * SCALE
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Black ring
    draw.ellipse([(0, 0), (s - 1, s - 1)], fill=(5, 6, 8, 255))
    # Chrome ring
    draw.ellipse([(SCALE, SCALE), (s - SCALE - 1, s - SCALE - 1)], fill=(200, 204, 212, 255))
    # Inner steel face
    inner = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    idraw = ImageDraw.Draw(inner)
    for y in range(s):
        t = y / max(s - 1, 1)
        r = int(106 - 64 * t)
        g = int(112 - 66 * t)
        b = int(120 - 68 * t)
        idraw.line([(0, y), (s, y)], fill=(r, g, b, 255))
    mask = Image.new("L", (s, s), 0)
    mdraw = ImageDraw.Draw(mask)
    mdraw.ellipse([(SCALE * 2, SCALE * 2), (s - SCALE * 2 - 1, s - SCALE * 2 - 1)], fill=255)
    inner.putalpha(mask)
    img = Image.alpha_composite(img, inner)
    img.save(f"{OUT}/replay_badge.png", "PNG")
    print(f"replay_badge.png ({s}x{s}, native circle — margin 6/6/6/6 at 3x: 18/18/18/18)")


# ----------------------------------------------------------------------
# 7-9) TIER STRIPS — thin colored bars with black border
# Source: 12x4 (4px tall stripe, 12px wide so corners are preserved)
# Patch margin: 4 / 1 / 4 / 1 (stretch horizontally, keep height fixed)
# ----------------------------------------------------------------------
def make_tier_strip(name, top_color, bot_color):
    w, h = 12 * SCALE, 4 * SCALE
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # 1px black border, rounded
    draw.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=SCALE, fill=(5, 6, 8, 255))
    # Inner colored gradient
    inner_top = SCALE
    inner_left = SCALE
    inner_right = w - SCALE - 1
    inner_bottom = h - SCALE - 1
    for y in range(inner_top, inner_bottom + 1):
        t = (y - inner_top) / max(inner_bottom - inner_top, 1)
        r = int(top_color[0] + (bot_color[0] - top_color[0]) * t)
        g = int(top_color[1] + (bot_color[1] - top_color[1]) * t)
        b = int(top_color[2] + (bot_color[2] - top_color[2]) * t)
        draw.line([(inner_left, y), (inner_right, y)], fill=(r, g, b, 255))
    img.save(f"{OUT}/tier_{name}.png", "PNG")
    print(f"tier_{name}.png ({w}x{h}, patch margin 4/1/4/1 at 3x: 12/3/12/3)")


make_card_body()
make_art_frame()
make_name_plate()
make_art_recess()
make_cost_coin()
make_replay_badge()
make_tier_strip("red",    (208, 72, 72),  (122, 24, 24))
make_tier_strip("yellow", (240, 200, 72), (168, 120, 16))
make_tier_strip("blue",   (90, 160, 216), (26, 74, 120))
print("done")
